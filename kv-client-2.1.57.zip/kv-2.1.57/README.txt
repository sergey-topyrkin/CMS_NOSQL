Oracle NoSQL Database 12cR1.2.1.57 Client: 2014-01-10 06:23:18 UTC

This is Oracle NoSQL Database, version 12cR1.2.1.57 Client.

To view the release and installation documentation, load the
distribution file doc/index.html into your web browser.
