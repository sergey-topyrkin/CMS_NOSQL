Oracle NoSQL Database 12cR1.2.1.57 Community Edition: 2014-01-10 06:20:10 UTC

This is Oracle NoSQL Database, version 12cR1.2.1.57 Community Edition.

To view the release and installation documentation, load the
distribution file doc/index.html into your web browser.
